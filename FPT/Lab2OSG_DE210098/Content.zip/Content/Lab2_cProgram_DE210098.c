#include <stdio.h>
#include <stdlib.h>

int main()
{
	int result;
	result = system("man pwd");
	return result;
}
