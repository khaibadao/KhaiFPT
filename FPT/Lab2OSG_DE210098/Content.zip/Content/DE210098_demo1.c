#include <stdio.h> 
#include <stdlib.h> 
#include <pthread.h> 
#include <unistd.h> 
int x = 0; 
void *threadFunc(void *vargp) 
{ 
	int myid = (int)vargp; 
	int v = 0; 
	++v; ++x;
	printf("x: %d ---- Myid: %d ---- v: %d\n", x, myid, v); 
	//add a line of code to print out myid, v, x 
} 
int main() 
{ 
	int i; 
	pthread_t tid[3];  
	for (i = 0; i < 3; i++) 
		pthread_create(&tid[i], NULL, threadFunc, (void *)i); 
	for (i = 0; i < 3; i++) 
		pthread_join(tid[i], NULL); 
	return 0;  
} 
